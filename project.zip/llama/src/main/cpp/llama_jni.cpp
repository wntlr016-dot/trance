// llama.cpp 기반 번역기 JNI (Hy-MT2 / Qwen3 등 GGUF)
#include <jni.h>
#include <string>
#include <vector>
#include <cstring>
#include "llama.h"

#ifdef __ANDROID__
#include <android/log.h>
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "jpsub-llama", __VA_ARGS__)
#else
#include <cstdio>
#define LOGI(...) do { fprintf(stderr, __VA_ARGS__); fprintf(stderr, "\n"); } while (0)
#endif

#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"

namespace {

struct Engine {
    llama_model         *model = nullptr;
    llama_context       *ctx   = nullptr;
    const llama_vocab   *vocab = nullptr;
    std::string          tmpl;      // 채팅 템플릿 (내장 이름 또는 jinja 원문)
    int                  n_ctx = 0;
};

void quiet_log(enum ggml_log_level level, const char *text, void *) {
    if (level >= GGML_LOG_LEVEL_WARN) LOGI("%s", text);
}

std::string apply_template(const Engine &e, const std::string &user) {
    llama_chat_message msg{"user", user.c_str()};
    std::vector<char> buf(user.size() * 2 + 512);
    int n = llama_chat_apply_template(e.tmpl.c_str(), &msg, 1, true, buf.data(), (int) buf.size());
    if (n > (int) buf.size()) {
        buf.resize(n + 1);
        n = llama_chat_apply_template(e.tmpl.c_str(), &msg, 1, true, buf.data(), (int) buf.size());
    }
    if (n < 0) {
        // 알 수 없는 템플릿이면 ChatML로 대체
        n = llama_chat_apply_template("chatml", &msg, 1, true, buf.data(), (int) buf.size());
        if (n > (int) buf.size()) {
            buf.resize(n + 1);
            n = llama_chat_apply_template("chatml", &msg, 1, true, buf.data(), (int) buf.size());
        }
    }
    return n > 0 ? std::string(buf.data(), n) : user;
}

std::string token_to_piece(const llama_vocab *vocab, llama_token t) {
    char buf[256];
    int n = llama_token_to_piece(vocab, t, buf, sizeof(buf), 0, false);
    if (n < 0) {
        std::vector<char> big(-n);
        n = llama_token_to_piece(vocab, t, big.data(), (int) big.size(), 0, false);
        return n > 0 ? std::string(big.data(), n) : std::string();
    }
    return std::string(buf, n);
}

} // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_personal_jpsub_LlamaLib_init(JNIEnv *env, jobject, jstring jpath, jint nCtx, jint threads) {
    static bool backend_ready = false;
    if (!backend_ready) {
        llama_log_set(quiet_log, nullptr);
        llama_backend_init();
        backend_ready = true;
    }

    const char *path = env->GetStringUTFChars(jpath, nullptr);
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    llama_model *model = llama_model_load_from_file(path, mp);
    env->ReleaseStringUTFChars(jpath, path);
    if (!model) { LOGI("model load failed"); return 0; }

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx           = (uint32_t) nCtx;
    cp.n_batch         = (uint32_t) nCtx;
    cp.n_threads       = threads;
    cp.n_threads_batch = threads;
    llama_context *ctx = llama_init_from_model(model, cp);
    if (!ctx) { llama_model_free(model); LOGI("context init failed"); return 0; }

    auto *e  = new Engine();
    e->model = model;
    e->ctx   = ctx;
    e->vocab = llama_model_get_vocab(model);
    e->n_ctx = nCtx;

    char arch[64] = {0};
    llama_model_meta_val_str(model, "general.architecture", arch, sizeof(arch));
    const char *jinja = llama_model_chat_template(model, nullptr);
    if (std::strcmp(arch, "hunyuan-dense") == 0) {
        e->tmpl = "hunyuan-dense";
    } else if (jinja) {
        e->tmpl = jinja;
    } else {
        e->tmpl = "chatml";
    }
    LOGI("loaded arch=%s", arch);
    return reinterpret_cast<jlong>(e);
}

JNIEXPORT void JNICALL
Java_com_personal_jpsub_LlamaLib_free(JNIEnv *, jobject, jlong h) {
    auto *e = reinterpret_cast<Engine *>(h);
    if (!e) return;
    llama_free(e->ctx);
    llama_model_free(e->model);
    delete e;
}

static jbyteArray to_bytes(JNIEnv *env, const std::string &s) {
    jbyteArray arr = env->NewByteArray((jsize) s.size());
    env->SetByteArrayRegion(arr, 0, (jsize) s.size(), reinterpret_cast<const jbyte *>(s.data()));
    return arr;
}

// 결과는 UTF-8 바이트 배열로 반환 (Kotlin에서 디코딩: 이모지·잘린 문자에도 안전)
JNIEXPORT jbyteArray JNICALL
Java_com_personal_jpsub_LlamaLib_generate(JNIEnv *env, jobject, jlong h, jstring jprompt, jint maxTokens) {
    auto *e = reinterpret_cast<Engine *>(h);
    if (!e) return to_bytes(env, "");

    const char *p = env->GetStringUTFChars(jprompt, nullptr);
    std::string user(p);
    env->ReleaseStringUTFChars(jprompt, p);

    const std::string prompt = apply_template(*e, user);

    // 토큰화
    int n_tok = -llama_tokenize(e->vocab, prompt.c_str(), (int) prompt.size(), nullptr, 0, true, true);
    std::vector<llama_token> toks(n_tok);
    if (llama_tokenize(e->vocab, prompt.c_str(), (int) prompt.size(), toks.data(), n_tok, true, true) < 0) {
        return to_bytes(env, "");
    }
    if (n_tok + maxTokens >= e->n_ctx) {
        // 문맥이 너무 길면 앞부분을 잘라냄
        int keep = e->n_ctx - maxTokens - 8;
        if (keep <= 0) return to_bytes(env, "");
        toks.erase(toks.begin(), toks.end() - keep);
        n_tok = keep;
    }

    // 매 번역마다 KV 캐시 초기화 (문장 단위 독립 번역)
    llama_memory_clear(llama_get_memory(e->ctx), true);

    if (llama_decode(e->ctx, llama_batch_get_one(toks.data(), n_tok)) != 0) {
        LOGI("prompt decode failed");
        return to_bytes(env, "");
    }

    // 모델 권장 샘플링: top_k 20, top_p 0.6, temp 0.7, repeat 1.05
    llama_sampler *smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, llama_sampler_init_top_k(20));
    llama_sampler_chain_add(smpl, llama_sampler_init_penalties(llama_vocab_n_tokens(e->vocab), 64, 1.05f, 0.0f, 0.0f));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.6f, 1));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(1234));

    std::string out;
    for (int i = 0; i < maxTokens; ++i) {
        llama_token t = llama_sampler_sample(smpl, e->ctx, -1);
        if (llama_vocab_is_eog(e->vocab, t)) break;
        out += token_to_piece(e->vocab, t);
        if (llama_decode(e->ctx, llama_batch_get_one(&t, 1)) != 0) break;
    }
    llama_sampler_free(smpl);

    return to_bytes(env, out);
}

} // extern "C"
