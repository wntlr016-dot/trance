cmake_minimum_required(VERSION 3.22.1)
project(jpsub_whisper C CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)
include(FetchContent)

# whisper.cpp(+ggml)를 이 .so 안에 정적으로 넣고 심볼을 숨긴다.
# (llama 모듈도 자체 ggml을 쓰므로 서로 충돌하지 않게)
set(BUILD_SHARED_LIBS      OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_TESTS    OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_SERVER   OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE            OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP            OFF CACHE BOOL "" FORCE)
if (ANDROID)
    set(GGML_CPU_ARM_ARCH "armv8.2-a+fp16+dotprod" CACHE STRING "" FORCE)
endif()

FetchContent_Declare(whisper
    GIT_REPOSITORY https://github.com/ggml-org/whisper.cpp.git
    GIT_TAG        v1.9.6
    GIT_SHALLOW    TRUE)
FetchContent_MakeAvailable(whisper)

add_library(jpsub_whisper SHARED whisper_jni.cpp)
target_compile_options(jpsub_whisper PRIVATE -O3)
target_link_libraries(jpsub_whisper PRIVATE whisper)
target_link_options(jpsub_whisper PRIVATE -Wl,--exclude-libs,ALL)
if (ANDROID)
    target_link_libraries(jpsub_whisper PRIVATE log)
endif()
