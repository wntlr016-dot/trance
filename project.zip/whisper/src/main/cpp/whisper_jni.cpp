#include <jni.h>
#include <string>
#include <vector>
#include "whisper.h"

#ifdef __ANDROID__
#include <android/log.h>
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "jpsub", __VA_ARGS__)
#else
#include <cstdio>
#define LOGI(...) do { fprintf(stderr, __VA_ARGS__); fprintf(stderr, "\n"); } while (0)
#endif

extern "C" {

static jbyteArray to_bytes(JNIEnv *env, const std::string &s) {
    jbyteArray arr = env->NewByteArray((jsize) s.size());
    env->SetByteArrayRegion(arr, 0, (jsize) s.size(), reinterpret_cast<const jbyte *>(s.data()));
    return arr;
}

JNIEXPORT jlong JNICALL
Java_com_personal_jpsub_WhisperLib_init(JNIEnv *env, jobject /*thiz*/, jstring modelPath) {
    const char *path = env->GetStringUTFChars(modelPath, nullptr);
    whisper_context_params cparams = whisper_context_default_params();
    cparams.use_gpu = false;
    cparams.flash_attn = true;   // CPU에서도 인코더가 빨라짐
    whisper_context *ctx = whisper_init_from_file_with_params(path, cparams);
    env->ReleaseStringUTFChars(modelPath, path);
    if (!ctx) LOGI("model load failed");
    return reinterpret_cast<jlong>(ctx);
}

JNIEXPORT void JNICALL
Java_com_personal_jpsub_WhisperLib_free(JNIEnv *, jobject, jlong ptr) {
    if (ptr) whisper_free(reinterpret_cast<whisper_context *>(ptr));
}

JNIEXPORT jbyteArray JNICALL
Java_com_personal_jpsub_WhisperLib_transcribe(JNIEnv *env, jobject, jlong ptr,
                                              jfloatArray samples, jstring lang,
                                              jint threads, jint audioCtx) {
    auto *ctx = reinterpret_cast<whisper_context *>(ptr);
    if (!ctx) return to_bytes(env, "");

    const jsize n = env->GetArrayLength(samples);
    std::vector<float> pcm(n);
    env->GetFloatArrayRegion(samples, 0, n, pcm.data());

    const char *language = env->GetStringUTFChars(lang, nullptr);
    std::string langStr(language);
    env->ReleaseStringUTFChars(lang, language);

    whisper_full_params p = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    p.n_threads        = threads;
    p.language         = langStr.c_str();
    p.translate        = false;
    p.no_context       = true;
    p.no_timestamps    = true;
    p.single_segment   = true;
    p.print_progress   = false;
    p.print_realtime   = false;
    p.print_special    = false;
    p.print_timestamps = false;
    p.suppress_blank   = true;
    p.suppress_nst     = true;
    p.temperature_inc  = 0.0f;   // 재시도(폴백) 없이 한 번만 → 지연 최소화
    p.audio_ctx        = audioCtx; // 0 = 기본(30초 창)

    if (whisper_full(ctx, p, pcm.data(), (int) pcm.size()) != 0) {
        LOGI("whisper_full failed");
        return to_bytes(env, "");
    }

    std::string out;
    const int segs = whisper_full_n_segments(ctx);
    for (int i = 0; i < segs; ++i) {
        if (whisper_full_get_segment_no_speech_prob(ctx, i) > 0.6f) continue;
        out += whisper_full_get_segment_text(ctx, i);
    }
    return to_bytes(env, out);
}

} // extern "C"
