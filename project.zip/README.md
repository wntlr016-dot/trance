# 일본어 영상 실시간 자막 (개인용)

영상에서 나오는 일본어 음성을 폰 안에서 인식하고 한국어로 번역해서 플로팅 자막으로 띄워 주는 안드로이드 앱입니다.

- 음성 인식: whisper.cpp (kotoba-whisper v2 / whisper small)
- 번역: llama.cpp (Hy-MT2 1.8B / Qwen3 1.7B, GGUF)
- 오디오 캡처: Android AudioPlaybackCapture (Android 10 이상)
- 처리는 전부 폰 안에서 하고, 모델을 받을 때만 인터넷을 씁니다.

## 빌드
GitHub에 올리면 Actions가 APK를 빌드합니다. 다 되면 **Releases → latest → jpsub.apk** 에서 받을 수 있습니다.

## 구조
- `app/` : UI, 캡처 서비스, 자막 창 (Kotlin)
- `whisper/` : whisper.cpp JNI (libjpsub_whisper.so)
- `llama/` : llama.cpp JNI (libjpsub_llama.so)
