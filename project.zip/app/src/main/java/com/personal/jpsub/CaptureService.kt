package com.personal.jpsub

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.concurrent.LinkedBlockingDeque
import java.util.concurrent.TimeUnit
import kotlin.math.max

/**
 * 다른 앱 소리 캡처 → 음성 구간 자르기 → Whisper 인식 → LLM 번역 → 플로팅 자막
 */
class CaptureService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "com.personal.jpsub.STOP"
        private const val CHANNEL = "jpsub"
        private const val NOTI_ID = 7
        private const val TAG = "jpsub"
        private const val SR = 16000

        @Volatile var running = false
            private set
    }

    private val main = Handler(Looper.getMainLooper())
    private var overlay: SubtitleOverlay? = null
    private var projection: MediaProjection? = null
    @Volatile private var recorder: AudioRecord? = null
    @Volatile private var stopping = false

    private val sttQueue = LinkedBlockingDeque<FloatArray>()
    private val mtQueue = LinkedBlockingDeque<String>()
    private val workers = mutableListOf<Thread>()
    @Volatile private var stt: SpeechToText? = null
    @Volatile private var vad: VoiceDetector? = null
    @Volatile private var lastSttMs = 0L
    private val debug = DebugSaver()
    @Volatile private var mt: LlmTranslator? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running || intent == null) return START_NOT_STICKY

        // Android 14+: 반드시 getMediaProjection 전에 포그라운드 시작
        startAsForeground()

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)

        val mpm = getSystemService(MediaProjectionManager::class.java)!!
        val proj = data?.let { runCatching { mpm.getMediaProjection(code, it) }.getOrNull() }
        if (proj == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, main)

        running = true
        overlay = SubtitleOverlay(this) { stopSelf() }.also { it.show() }

        val boot = Thread({ bootAndCapture() }, "jpsub-capture")
        workers += boot
        boot.start()
        return START_NOT_STICKY
    }

    private fun status(msg: String) = main.post { overlay?.setStatus(msg) }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)!!
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "자막 실행 중", NotificationManager.IMPORTANCE_LOW))
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("일본어 자막 실행 중")
            .setContentText("영상 소리를 번역하고 있어요")
            .setContentIntent(openIntent)
            .addAction(0, "중지", stopIntent)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, NOTI_ID, n,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
    }

    // ───────────────────────── 모델 로드 + 캡처 루프 ─────────────────────────

    private fun bootAndCapture() {
        try {
            val sttDef = Models.byId(Prefs.sttId(this)) ?: Models.STT[0]
            val mtDef = Models.byId(Prefs.mtId(this)) ?: Models.MT[0]
            Models.migrate(this)
            if (!Models.isReady(this, sttDef) || !Models.isReady(this, mtDef)) {
                status("모델이 없어요. 앱에서 먼저 다운로드하세요.")
                return
            }
            status("음성 인식 모델 불러오는 중…")
            if (!Models.isReady(this, Models.VAD)) { status("VAD 모델이 없어요. 앱에서 다시 다운로드하세요."); return }
            vad = VoiceDetector(Models.file(this, Models.VAD))
            val s: SpeechToText = if (sttDef.id == "reazon")
                ReazonStt(Models.dir(this, sttDef), threads = 4)
            else
                WhisperStt(Models.file(this, sttDef), threads = 4)
            if (!s.ok) { status("음성 인식 모델을 열 수 없어요"); return }
            stt = s
            if (stopping) return

            status("번역 모델 불러오는 중…")
            val t = LlmTranslator(Models.file(this, mtDef), mtDef.id, threads = 4)
            if (!t.ok) { status("번역 모델을 열 수 없어요 (다른 번역 모델을 골라 보세요)"); return }
            mt = t
            if (stopping) return

            startWorkers()
            status("듣는 중… 영상을 재생하세요")
            captureLoop()
        } catch (e: Throwable) {
            Log.e(TAG, "boot failed", e)
            status("오류: ${e.message}")
        }
    }

    private fun startWorkers() {
        val sttThread = Thread({
            while (!stopping) {
                val chunk = try { sttQueue.poll(500, TimeUnit.MILLISECONDS) } catch (_: InterruptedException) { break } ?: continue
                val t0 = System.currentTimeMillis()
                val ja = stt?.transcribe(chunk).orEmpty()
                lastSttMs = System.currentTimeMillis() - t0
                var peak = 0f
                for (x in chunk) if (kotlin.math.abs(x) > peak) peak = kotlin.math.abs(x)
                debug.log("구간 %.1f초 (최대음량 %.2f) 인식 %dms → %s".format(chunk.size / 16000f, peak, lastSttMs, ja.ifBlank { "(없음)" }))
                if (ja.isBlank() || stopping) continue
                main.post { overlay?.showJapanese(ja) }
                mtQueue.offer(ja)
                while (mtQueue.size > 2) mtQueue.pollFirst() // 밀리면 오래된 것 버림
            }
        }, "jpsub-stt")

        val mtThread = Thread({
            val history = ArrayDeque<String>()
            while (!stopping) {
                val ja = try { mtQueue.poll(500, TimeUnit.MILLISECONDS) } catch (_: InterruptedException) { break } ?: continue
                val ctx = if (Prefs.useContext(this)) history.toList() else emptyList()
                val t0 = System.currentTimeMillis()
                val ko = mt?.translate(ja, ctx).orEmpty()
                val mtMs = System.currentTimeMillis() - t0
                debug.log("번역 %dms → %s".format(mtMs, ko.ifBlank { "(없음)" }))
                if (stopping) break
                val timing = if (Prefs.showTiming(this)) "인식 %.1f초 · 번역 %.1f초".format(lastSttMs / 1000f, mtMs / 1000f) else ""
                main.post { overlay?.showTranslation(ja, ko, timing) }
                history.addLast(ja)
                while (history.size > 2) history.removeFirst()
            }
        }, "jpsub-mt")

        workers += sttThread
        workers += mtThread
        sttThread.start()
        mtThread.start()
    }

    @SuppressLint("MissingPermission")
    private fun captureLoop() {
        val proj = projection ?: return
        val config = AudioPlaybackCaptureConfiguration.Builder(proj)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SR)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord.Builder()
            .setAudioFormat(format)
            .setBufferSizeInBytes(max(minBuf, SR * 2))
            .setAudioPlaybackCaptureConfig(config)
            .build()
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            status("오디오 캡처를 시작할 수 없어요")
            rec.release()
            return
        }
        recorder = rec
        rec.startRecording()

        val v = vad ?: return
        val frame = ShortArray(VoiceDetector.WINDOW)
        val fbuf = FloatArray(VoiceDetector.WINDOW)
        while (!stopping) {
            var off = 0
            while (off < frame.size && !stopping) {
                val n = rec.read(frame, off, frame.size - off)
                if (n < 0) { status("오디오 읽기 오류 ($n)"); return }
                off += n
            }
            if (stopping) break
            for (i in frame.indices) fbuf[i] = frame[i] / 32768f
            debug.addAudio(fbuf)
            for (seg in v.accept(fbuf)) emit(seg)
        }
    }

    private fun emit(seg: FloatArray) {
        if (seg.size < SR / 4) return // 0.25초 미만 무시
        sttQueue.offer(seg)
        while (sttQueue.size > 2) sttQueue.pollFirst() // 지연이 쌓이면 오래된 구간 버림
    }

    // ───────────────────────── 종료 ─────────────────────────

    override fun onDestroy() {
        stopping = true
        running = false
        overlay?.remove()
        overlay = null
        runCatching { recorder?.stop() }
        runCatching { projection?.stop() }
        val toJoin = workers.toList()
        // 추론 중인 스레드가 끝난 뒤에 모델 메모리 해제
        Thread {
            toJoin.forEach { runCatching { it.join(15000) } }
            runCatching { recorder?.release() }
            stt?.close(); stt = null
            vad?.close(); vad = null
            val where = debug.save(this@CaptureService)
            if (where != null) main.post {
                android.widget.Toast.makeText(this@CaptureService, "진단 기록을 $where 에 저장했어요", android.widget.Toast.LENGTH_LONG).show()
            }
            mt?.close(); mt = null
        }.start()
        super.onDestroy()
    }
}
