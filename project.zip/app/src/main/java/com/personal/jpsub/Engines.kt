package com.personal.jpsub

import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineTransducerModelConfig
import com.k2fsa.sherpa.onnx.SileroVadModelConfig
import com.k2fsa.sherpa.onnx.Vad
import com.k2fsa.sherpa.onnx.VadModelConfig
import java.io.File

/** 일본어 음성(16kHz mono float) → 텍스트 */
interface SpeechToText {
    val ok: Boolean
    fun transcribe(pcm: FloatArray): String
    fun close()
}

/** ReazonSpeech (sherpa-onnx, Zipformer transducer). 일본어 전용, 매우 빠름 */
class ReazonStt(dir: File, threads: Int) : SpeechToText {
    private val rec: OfflineRecognizer? = runCatching {
        OfflineRecognizer(
            config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    transducer = OfflineTransducerModelConfig(
                        encoder = File(dir, "encoder.int8.onnx").path,
                        decoder = File(dir, "decoder.int8.onnx").path,
                        joiner = File(dir, "joiner.int8.onnx").path,
                    ),
                    tokens = File(dir, "tokens.txt").path,
                    numThreads = threads,
                    provider = "cpu",
                    debug = false,
                ),
                decodingMethod = "greedy_search",
            )
        )
    }.getOrNull()

    override val ok get() = rec != null

    override fun transcribe(pcm: FloatArray): String {
        val r = rec ?: return ""
        val stream = r.createStream()
        return try {
            stream.acceptWaveform(pcm, 16000)
            r.decode(stream)
            cleanupJa(r.getResult(stream).text)
        } finally {
            stream.release()
        }
    }

    override fun close() { rec?.release() }
}

/** whisper.cpp (kotoba-whisper). 정확도 우선, 느림 */
class WhisperStt(modelFile: File, private val threads: Int) : SpeechToText {
    private val ctx: Long = WhisperLib.init(modelFile.absolutePath)
    override val ok get() = ctx != 0L

    override fun transcribe(pcm: FloatArray): String {
        if (!ok) return ""
        // 정확도를 위해 전체 인코더 창 사용 (audio_ctx = 0)
        val text = WhisperLib.transcribe(ctx, pcm, "ja", threads, 0).toString(Charsets.UTF_8)
        return cleanupJa(text)
    }

    override fun close() { if (ok) WhisperLib.free(ctx) }
}

private val HALLUCINATIONS = listOf(
    "ご視聴ありがとうございました", "ご視聴ありがとうございます", "チャンネル登録",
    "最後までご視聴", "高評価", "字幕作成"
)

private fun cleanupJa(t: String): String {
    var s = t.replace(Regex("\\[.*?]|\\(.*?\\)|（.*?）|♪+"), "").trim()
    if (HALLUCINATIONS.any { s.contains(it) }) return ""
    s = s.replace(Regex("(.{1,6}?)\\1{4,}"), "$1$1$1") // 반복 폭주 억제
    return if (s.length < 2) "" else s
}

/**
 * Silero VAD: 배경음악 속에서도 사람 목소리 구간만 잘라냄.
 * VAD가 말 시작을 조금 늦게 잡아서 첫 음절이 잘리므로, 최근 오디오를 보관해 두었다가
 * 구간 앞에 0.5초를 붙여서 돌려줌.
 */
class VoiceDetector(modelFile: File) {
    private val vad = Vad(
        config = VadModelConfig(
            sileroVadModelConfig = SileroVadModelConfig(
                model = modelFile.path,
                threshold = 0.4f,
                minSilenceDuration = 0.45f,   // 0.45초 쉬면 문장 끝
                minSpeechDuration = 0.25f,
                windowSize = WINDOW,
                maxSpeechDuration = 8.0f,     // 길게 이어지면 8초에서 끊음
            ),
            sampleRate = 16000,
            numThreads = 1,
            provider = "cpu",
        )
    )

    private val ring = FloatArray(16000 * 30)
    private var total = 0L // 지금까지 넣은 샘플 수

    /** WINDOW(512) 샘플씩 넣고, 완성된 말 구간이 있으면 돌려줌 */
    fun accept(samples: FloatArray): List<FloatArray> {
        for (v in samples) { ring[(total % ring.size).toInt()] = v; total++ }
        vad.acceptWaveform(samples)
        val out = ArrayList<FloatArray>()
        while (!vad.empty()) {
            val seg = vad.front()
            vad.pop()
            out += withPreRoll(seg.start.toLong(), seg.samples)
        }
        return out
    }

    private fun withPreRoll(start: Long, samples: FloatArray): FloatArray {
        val from = maxOf(0L, start - PRE_ROLL, total - ring.size + 1)
        val to = start + samples.size
        if (from >= start || to > total) return samples
        return FloatArray((to - from).toInt()) { i -> ring[((from + i) % ring.size).toInt()] }
    }

    fun close() = vad.release()

    companion object {
        const val WINDOW = 512
        private const val PRE_ROLL = 8000L // 0.5초
    }
}

/** 일본어 → 한국어 번역 (GGUF LLM) */
class LlmTranslator(modelFile: File, private val modelId: String, threads: Int) {
    private val handle: Long = LlamaLib.init(modelFile.absolutePath, 1024, threads)
    val ok get() = handle != 0L

    fun translate(src: String, context: List<String>): String {
        if (!ok || src.isBlank()) return ""
        val raw = LlamaLib.generate(handle, buildPrompt(src, context), 96).toString(Charsets.UTF_8)
        return cleanup(raw)
    }

    fun close() { if (ok) LlamaLib.free(handle) }

    private fun buildPrompt(src: String, ctx: List<String>): String = when (modelId) {
        "hymt2" -> if (ctx.isEmpty()) {
            "Translate the following segment into Korean, without additional explanation.\n\n$src"
        } else {
            ctx.joinToString("\n") +
                "\n\nPlease translate the following text into Korean, taking the provided background information into consideration. " +
                "Only output the translation of the following text, without translating the background or adding explanations.\n\n" + src
        }
        else -> buildString {
            append("다음 일본어 영상 자막을 자연스러운 한국어 구어체로 번역하세요. 말투(반말/존댓말)를 살리고, 번역문 한 줄만 출력하세요.\n")
            if (ctx.isNotEmpty()) {
                append("\n[앞 대사 (참고용, 번역하지 말 것)]\n")
                ctx.forEach { append(it).append('\n') }
            }
            append("\n[번역할 대사]\n").append(src).append(" /no_think")
        }
    }

    private fun cleanup(t: String): String {
        val s = t.replace(Regex("(?s)<think>.*?</think>"), "")
            .replace("<think>", "").replace("</think>", "")
            .trim()
        val line = s.lines().map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: ""
        return line.removePrefix("번역:").trim().trim('"', '「', '」', '“', '”')
    }
}
