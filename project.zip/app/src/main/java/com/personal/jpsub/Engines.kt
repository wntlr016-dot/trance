package com.personal.jpsub

import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineTransducerModelConfig
import com.k2fsa.sherpa.onnx.SileroVadModelConfig
import com.k2fsa.sherpa.onnx.Vad
import com.k2fsa.sherpa.onnx.VadModelConfig
import java.io.File

/** 일본어 음성(16kHz mono float) → 텍스트 */
interface SpeechToText {
    val ok: Boolean
    fun transcribe(pcm: FloatArray): String
    fun close()
}

/** ReazonSpeech (sherpa-onnx, Zipformer transducer). 일본어 전용, 매우 빠름 */
class ReazonStt(dir: File, threads: Int) : SpeechToText {
    private val rec: OfflineRecognizer? = runCatching {
        OfflineRecognizer(
            config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    transducer = OfflineTransducerModelConfig(
                        encoder = File(dir, "encoder.int8.onnx").path,
                        decoder = File(dir, "decoder.int8.onnx").path,
                        joiner = File(dir, "joiner.int8.onnx").path,
                    ),
                    tokens = File(dir, "tokens.txt").path,
                    numThreads = threads,
                    provider = "cpu",
                    debug = false,
                ),
                decodingMethod = "greedy_search",
            )
        )
    }.getOrNull()

    override val ok get() = rec != null

    override fun transcribe(pcm: FloatArray): String {
        val r = rec ?: return ""
        val stream = r.createStream()
        return try {
            stream.acceptWaveform(pcm, 16000)
            r.decode(stream)
            cleanupJa(r.getResult(stream).text)
        } finally {
            stream.release()
        }
    }

    override fun close() { rec?.release() }
}

/** whisper.cpp (kotoba-whisper). 정확도 우선, 느림 */
class WhisperStt(modelFile: File, private val threads: Int) : SpeechToText {
    private val ctx: Long = WhisperLib.init(modelFile.absolutePath)
    override val ok get() = ctx != 0L

    override fun transcribe(pcm: FloatArray): String {
        if (!ok) return ""
        // 정확도를 위해 전체 인코더 창 사용 (audio_ctx = 0)
        val text = WhisperLib.transcribe(ctx, pcm, "ja", threads, 0).toString(Charsets.UTF_8)
        return cleanupJa(text)
    }

    override fun close() { if (ok) WhisperLib.free(ctx) }
}

private val HALLUCINATIONS = listOf(
    "ご視聴ありがとうございました", "ご視聴ありがとうございます", "チャンネル登録",
    "最後までご視聴", "高評価", "字幕作成"
)

/** 자주 틀리는 인식 결과 교정 (발음이 같은 다른 한자로 나오는 경우) */
private val ASR_FIX = listOf("製士" to "精子", "精士" to "精子")

private fun cleanupJa(t: String): String {
    var s = t.replace(Regex("\\[.*?]|\\(.*?\\)|（.*?）|♪+"), "")
        .replace(Regex("[《》〈〉『』「」【】]"), "").trim()
    if (HALLUCINATIONS.any { s.contains(it) }) return ""
    for ((wrong, right) in ASR_FIX) s = s.replace(wrong, right)
    s = s.replace(Regex("(.{1,6}?)\\1{4,}"), "$1$1$1") // 반복 폭주 억제
    return if (s.length < 2) "" else s
}

/** 사용자 용어집: "일본어=한국어" 한 줄에 하나. 번역할 때 해당 단어가 있으면 이 번역을 쓰라고 지시 */
object Glossary {
    val DEFAULT = """
ちんちん=자지
おちんちん=자지
ちんぽ=자지
しこしこ=딸딸이
精子=정액
イく=가다
イっちゃう=갈 것 같아
出したい=싸고 싶어
出させない=못 싸게 할 거야
出して=싸
我慢=참기
気持ちいい=기분 좋아
""".trim()

    fun parse(text: String): List<Pair<String, String>> = text.lines()
        .mapNotNull { l -> l.split("=", limit = 2).takeIf { it.size == 2 }?.let { it[0].trim() to it[1].trim() } }
        .filter { it.first.isNotEmpty() && it.second.isNotEmpty() }
        .sortedByDescending { it.first.length }

    /** 문장에 들어 있는 용어 (긴 것 우선, 겹치는 짧은 것 제외, 최대 5개) */
    fun matches(src: String, terms: List<Pair<String, String>>): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        for (t in terms) {
            if (out.size >= 5) break
            if (src.contains(t.first) && out.none { it.first.contains(t.first) }) out += t
        }
        return out
    }
}

/** 감탄사·짧은 대답 처리 (LLM에 넣으면 앞 대사를 대신 번역하는 등 엉뚱해지기 쉬움) */
object Interjection {
    private val KANA_ONLY = Regex("^[あぁいぃうぅえぇおぉんっーゃゅょはひふへほアァイィウゥエェオォンッーハヒフヘホャュョ〜～…、。！？!?\\s]+$")

    /** 의미 있는 짧은 대답: 항상 표시, 사전으로 바로 번역 */
    private val MEANINGFUL = mapOf(
        "はい" to "네", "うん" to "응", "ええ" to "네", "いいえ" to "아니요", "ううん" to "아니",
        "いや" to "아니", "えっ" to "어?", "え" to "어?", "ほら" to "봐", "もう" to "정말"
    )

    /** 소리 감탄사: '감탄사 숨기기'를 끄면 이렇게 표시 */
    private val SOUNDS = mapOf(
        "ああ" to "아아", "あっ" to "앗", "はあ" to "하아", "ふふ" to "후후", "フフ" to "후후",
        "へえ" to "헤에", "おお" to "오오"
    )

    private fun key(s: String) = s.replace(Regex("[、。！？!?…〜～ー\\s]"), "")

    /** 사전 번역 결과. 없으면 null */
    fun lookup(ja: String): String? = key(ja).let { MEANINGFUL[it] ?: SOUNDS[it] }

    /** 신음·감탄사처럼 가나 몇 글자뿐인 구간 (의미 있는 대답은 제외) */
    fun isPureInterjection(ja: String): Boolean {
        val k = key(ja)
        return k.length <= 6 && KANA_ONLY.matches(ja) && MEANINGFUL[k] == null
    }

    /** 짧아서 앞 대사 문맥을 주면 안 되는 구간 */
    fun isShort(ja: String) = key(ja).length < 5
}

/**
 * Silero VAD: 배경음악 속에서도 사람 목소리 구간만 잘라냄.
 * VAD가 말 시작을 조금 늦게 잡아서 첫 음절이 잘리므로, 최근 오디오를 보관해 두었다가
 * 구간 앞에 0.5초를 붙여서 돌려줌.
 */
class VoiceDetector(modelFile: File) {
    private val vad = Vad(
        config = VadModelConfig(
            sileroVadModelConfig = SileroVadModelConfig(
                model = modelFile.path,
                threshold = 0.4f,
                minSilenceDuration = 0.45f,   // 0.45초 쉬면 문장 끝
                minSpeechDuration = 0.25f,
                windowSize = WINDOW,
                maxSpeechDuration = 8.0f,     // 길게 이어지면 8초에서 끊음
            ),
            sampleRate = 16000,
            numThreads = 1,
            provider = "cpu",
        )
    )

    private val ring = FloatArray(16000 * 30)
    private var total = 0L // 지금까지 넣은 샘플 수

    /** WINDOW(512) 샘플씩 넣고, 완성된 말 구간이 있으면 돌려줌 */
    fun accept(samples: FloatArray): List<FloatArray> {
        for (v in samples) { ring[(total % ring.size).toInt()] = v; total++ }
        vad.acceptWaveform(samples)
        val out = ArrayList<FloatArray>()
        while (!vad.empty()) {
            val seg = vad.front()
            vad.pop()
            out += withPreRoll(seg.start.toLong(), seg.samples)
        }
        return out
    }

    private fun withPreRoll(start: Long, samples: FloatArray): FloatArray {
        val from = maxOf(0L, start - PRE_ROLL, total - ring.size + 1)
        val to = start + samples.size
        if (from >= start || to > total) return samples
        return FloatArray((to - from).toInt()) { i -> ring[((from + i) % ring.size).toInt()] }
    }

    fun close() = vad.release()

    companion object {
        const val WINDOW = 512
        private const val PRE_ROLL = 8000L // 0.5초
    }
}

/** 일본어 → 한국어 번역 (GGUF LLM) */
class LlmTranslator(modelFile: File, private val modelId: String, threads: Int) {
    private val handle: Long = LlamaLib.init(modelFile.absolutePath, 1024, threads)
    val ok get() = handle != 0L

    var glossary: List<Pair<String, String>> = emptyList()

    fun translate(src: String, context: List<String>): String {
        if (!ok || src.isBlank()) return ""
        Interjection.lookup(src)?.let { return it }
        val terms = Glossary.matches(src, glossary)
        val ctx = if (Interjection.isShort(src) || terms.isNotEmpty()) emptyList() else context
        var out = run(src, ctx, terms)
        // 앞 대사까지 번역해 버렸거나(너무 김) 일본어가 남아 있으면 문맥 없이 다시 번역
        if (ctx.isNotEmpty() && (out.length > src.length * 3 + 12 || KANA.containsMatchIn(out))) {
            out = run(src, emptyList(), terms)
        }
        return out.replace(KANA, "").trim()
    }

    private fun run(src: String, ctx: List<String>, terms: List<Pair<String, String>>): String =
        cleanup(LlamaLib.generate(handle, buildPrompt(src, ctx, terms), 96).toString(Charsets.UTF_8))

    private companion object {
        val KANA = Regex("[\\u3040-\\u30ff]+")
    }

    fun close() { if (ok) LlamaLib.free(handle) }

    private fun buildPrompt(src: String, ctx: List<String>, terms: List<Pair<String, String>>): String = when (modelId) {
        "hymt2" -> if (terms.isNotEmpty()) {
            // Hy-MT 공식 '용어 지정 번역' 템플릿
            "参考下面的翻译：\n" + terms.joinToString("\n") { "${it.first} 翻译成 ${it.second}" } +
                "\n\n将以下文本翻译为韩语，注意只需要输出翻译后的结果，不要额外解释：\n" + src
        } else if (ctx.isEmpty()) {
            "Translate the following segment into Korean, without additional explanation.\n\n$src"
        } else {
            ctx.joinToString("\n") +
                "\n\nPlease translate the following text into Korean, taking the provided background information into consideration. " +
                "Only output the translation of the following text, without translating the background or adding explanations.\n\n" + src
        }
        else -> buildString {
            append("다음 일본어 영상 자막을 자연스러운 한국어 구어체로 번역하세요. 말투(반말/존댓말)를 살리고, 번역문 한 줄만 출력하세요.\n")
            if (terms.isNotEmpty()) {
                append("\n[용어집: 반드시 이 번역을 사용]\n")
                terms.forEach { append(it.first).append(" → ").append(it.second).append('\n') }
            }
            if (ctx.isNotEmpty()) {
                append("\n[앞 대사 (참고용, 번역하지 말 것)]\n")
                ctx.forEach { append(it).append('\n') }
            }
            append("\n[번역할 대사]\n").append(src).append(" /no_think")
        }
    }

    private fun cleanup(t: String): String {
        val s = t.replace(Regex("(?s)<think>.*?</think>"), "")
            .replace("<think>", "").replace("</think>", "")
            .trim()
        val line = s.lines().map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: ""
        return line.removePrefix("번역:").trim()
            .replace(Regex("[《》〈〉『』「」【】\"“”]"), "").trim()
    }
}
