package com.personal.jpsub

import java.io.File

/** 일본어 음성 → 텍스트 */
class SpeechRecognizer(modelFile: File, private val threads: Int) {
    private val ctx: Long = WhisperLib.init(modelFile.absolutePath)
    val ok get() = ctx != 0L

    fun transcribe(pcm: FloatArray): String {
        if (!ok) return ""
        // 오디오 길이에 맞춰 인코더 창을 줄이면 훨씬 빨라짐 (30초 창 = 1500)
        val sec = pcm.size / 16000f
        val audioCtx = ((sec * 50).toInt() + 64).coerceIn(256, 1500)
        val text = WhisperLib.transcribe(ctx, pcm, "ja", threads, audioCtx).toString(Charsets.UTF_8).trim()
        return cleanup(text)
    }

    fun close() { if (ok) WhisperLib.free(ctx) }

    private fun cleanup(t: String): String {
        var s = t.replace(Regex("\\[.*?]|\\(.*?\\)|（.*?）|♪+"), "").trim()
        // Whisper가 무음·음악에서 자주 지어내는 문장 제거
        if (HALLUCINATIONS.any { s.contains(it) }) return ""
        // 같은 글자/구절 반복 폭주 억제
        s = s.replace(Regex("(.{1,6}?)\\1{4,}"), "$1$1$1")
        return if (s.length < 2) "" else s
    }

    companion object {
        private val HALLUCINATIONS = listOf(
            "ご視聴ありがとうございました", "ご視聴ありがとうございます", "チャンネル登録",
            "最後までご視聴", "高評価", "字幕作成", "おやすみなさい。おやすみなさい"
        )
    }
}

/** 일본어 → 한국어 번역 (GGUF LLM) */
class LlmTranslator(modelFile: File, private val modelId: String, threads: Int) {
    private val handle: Long = LlamaLib.init(modelFile.absolutePath, 1024, threads)
    val ok get() = handle != 0L

    fun translate(src: String, context: List<String>): String {
        if (!ok || src.isBlank()) return ""
        val prompt = buildPrompt(src, context)
        val raw = LlamaLib.generate(handle, prompt, 128).toString(Charsets.UTF_8)
        return cleanup(raw)
    }

    fun close() { if (ok) LlamaLib.free(handle) }

    private fun buildPrompt(src: String, ctx: List<String>): String = when (modelId) {
        "hymt2" -> if (ctx.isEmpty()) {
            "Translate the following segment into Korean, without additional explanation.\n\n$src"
        } else {
            // Hy-MT 공식 '문맥 번역' 템플릿
            ctx.joinToString("\n") + "\n参考上面的信息，把下面的文本翻译成韩语，注意不需要翻译上文，也不要额外解释：\n" + src
        }
        else -> buildString {
            append("다음 일본어 영상 자막을 자연스러운 한국어 구어체로 번역하세요. 말투(반말/존댓말)를 살리고, 번역문 한 줄만 출력하세요.\n")
            if (ctx.isNotEmpty()) {
                append("\n[앞 대사 (참고용, 번역하지 말 것)]\n")
                ctx.forEach { append(it).append('\n') }
            }
            append("\n[번역할 대사]\n").append(src).append(" /no_think")
        }
    }

    private fun cleanup(t: String): String {
        val s = t.replace(Regex("(?s)<think>.*?</think>"), "")
            .replace("<think>", "").replace("</think>", "")
            .trim()
        val line = s.lines().map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: ""
        return line.removePrefix("번역:").trim().trim('"', '「', '」', '“', '”')
    }
}
