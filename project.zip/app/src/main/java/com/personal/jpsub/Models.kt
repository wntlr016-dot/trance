package com.personal.jpsub

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

enum class ModelKind { STT, MT, VAD }

data class ModelFile(val url: String, val name: String)

data class ModelDef(
    val id: String,
    val kind: ModelKind,
    val label: String,
    val files: List<ModelFile>,
    val sizeMb: Int,
)

object Models {
    private const val REAZON = "https://huggingface.co/csukuangfj/reazonspeech-k2-v2/resolve/main/"

    /** 말소리 구간 감지 (항상 필요, 2MB) */
    val VAD = ModelDef(
        "silero", ModelKind.VAD, "Silero VAD",
        listOf(ModelFile("https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/silero_vad.onnx", "silero_vad.onnx")),
        2
    )

    val STT = listOf(
        ModelDef(
            "reazon", ModelKind.STT, "ReazonSpeech (일본어 전용·빠름·추천)",
            listOf(
                ModelFile(REAZON + "encoder-epoch-99-avg-1.int8.onnx", "encoder.int8.onnx"),
                ModelFile(REAZON + "decoder-epoch-99-avg-1.int8.onnx", "decoder.int8.onnx"),
                ModelFile(REAZON + "joiner-epoch-99-avg-1.int8.onnx", "joiner.int8.onnx"),
                ModelFile(REAZON + "tokens.txt", "tokens.txt"),
            ),
            161
        ),
        ModelDef(
            "kotoba", ModelKind.STT, "kotoba-whisper v2 (정확하지만 느림)",
            listOf(ModelFile(
                "https://huggingface.co/kotoba-tech/kotoba-whisper-v2.0-ggml/resolve/main/ggml-kotoba-whisper-v2.0-q5_0.bin",
                "ggml-kotoba-whisper-v2.0-q5_0.bin"
            )),
            538
        ),
    )

    val MT = listOf(
        ModelDef(
            "hymt2", ModelKind.MT, "Hy-MT2 1.8B (번역 전용·추천)",
            listOf(ModelFile(
                "https://huggingface.co/tencent/Hy-MT2-1.8B-GGUF/resolve/main/Hy-MT2-1.8B-Q4_K_M.gguf",
                "Hy-MT2-1.8B-Q4_K_M.gguf"
            )),
            1130
        ),
        ModelDef(
            "qwen3", ModelKind.MT, "Qwen3 1.7B (범용 LLM)",
            listOf(ModelFile(
                "https://huggingface.co/unsloth/Qwen3-1.7B-GGUF/resolve/main/Qwen3-1.7B-Q4_K_M.gguf",
                "Qwen3-1.7B-Q4_K_M.gguf"
            )),
            1110
        ),
    )

    private fun root(ctx: Context): File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "models").apply { mkdirs() }
    fun dir(ctx: Context, m: ModelDef): File = File(root(ctx), m.id).apply { mkdirs() }
    fun file(ctx: Context, m: ModelDef, name: String = m.files[0].name) = File(dir(ctx, m), name)

    fun isReady(ctx: Context, m: ModelDef) = m.files.all { file(ctx, m, it.name).let { f -> f.exists() && f.length() > 0 } }

    /** 이전 버전(1.0)은 models/ 바로 아래에 저장했음 → 다시 받지 않도록 새 위치로 옮김 */
    fun migrate(ctx: Context) {
        for (m in STT + MT) for (f in m.files) {
            val old = File(root(ctx), f.name)
            if (old.isFile) old.renameTo(file(ctx, m, f.name))
        }
    }

    fun byId(id: String?): ModelDef? = (STT + MT + VAD).firstOrNull { it.id == id }

    /** 모델의 모든 파일을 이어받기 지원으로 다운로드. onProgress(파일명, 받은 바이트, 전체 바이트) */
    fun download(ctx: Context, m: ModelDef, onProgress: (String, Long, Long) -> Unit, cancelled: () -> Boolean) {
        for (f in m.files) {
            val target = file(ctx, m, f.name)
            if (target.exists() && target.length() > 0) continue
            downloadOne(f.url, target, { d, t -> onProgress(f.name, d, t) }, cancelled)
        }
    }

    private fun downloadOne(src: String, target: File, onProgress: (Long, Long) -> Unit, cancelled: () -> Boolean) {
        val part = File(target.path + ".part")
        var url = URL(src)
        var conn: HttpURLConnection
        var redirects = 0
        while (true) {
            conn = url.openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = false
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.setRequestProperty("User-Agent", "jpsub/1.1")
            if (part.exists() && part.length() > 0) conn.setRequestProperty("Range", "bytes=${part.length()}-")
            val code = conn.responseCode
            if (code in 300..399 && redirects < 10) {
                val loc = conn.getHeaderField("Location") ?: throw Exception("리다이렉트 주소 없음")
                url = URL(url, loc)
                conn.disconnect()
                redirects++
                continue
            }
            if (code == 416) { conn.disconnect(); part.renameTo(target); return }
            if (code != 200 && code != 206) throw Exception("HTTP $code (${target.name})")
            break
        }
        val append = conn.responseCode == 206
        val already = if (append) part.length() else 0L
        val total = already + conn.contentLengthLong.coerceAtLeast(0)
        conn.inputStream.use { input ->
            FileOutputStream(part, append).use { out ->
                val buf = ByteArray(1 shl 16)
                var done = already
                var lastReport = 0L
                while (true) {
                    if (cancelled()) throw InterruptedException("취소됨")
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (done - lastReport > 2_000_000) { lastReport = done; onProgress(done, total) }
                }
                onProgress(done, total)
            }
        }
        conn.disconnect()
        if (total > 0 && part.length() < total) throw Exception("다운로드가 끊겼어요. 다시 누르면 이어받아요.")
        if (!part.renameTo(target)) throw Exception("파일 저장 실패")
    }
}

object Prefs {
    private const val NAME = "jpsub"
    fun sp(ctx: Context) = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun sttId(ctx: Context) = sp(ctx).getString("stt2", "reazon")!!
    fun mtId(ctx: Context) = sp(ctx).getString("mt", "hymt2")!!
    fun textSize(ctx: Context) = sp(ctx).getInt("textSize", 20)
    fun showOriginal(ctx: Context) = sp(ctx).getBoolean("showOriginal", true)
    fun useContext(ctx: Context) = sp(ctx).getBoolean("useContext", true)
    fun hideInterjections(ctx: Context) = sp(ctx).getBoolean("hideInterj", true)
    fun glossary(ctx: Context) = sp(ctx).getString("glossary", Glossary.DEFAULT)!!
    fun showTiming(ctx: Context) = sp(ctx).getBoolean("showTiming", true)
    fun overlayY(ctx: Context) = sp(ctx).getInt("overlayY", -1)

    fun set(ctx: Context, key: String, v: Any) {
        val e = sp(ctx).edit()
        when (v) {
            is String -> e.putString(key, v)
            is Int -> e.putInt(key, v)
            is Boolean -> e.putBoolean(key, v)
        }
        e.apply()
    }
}
