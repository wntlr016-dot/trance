package com.personal.jpsub

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

enum class ModelKind { STT, MT }

data class ModelDef(
    val id: String,
    val kind: ModelKind,
    val label: String,
    val url: String,
    val fileName: String,
    val sizeMb: Int,
)

object Models {
    val STT = listOf(
        ModelDef(
            "kotoba", ModelKind.STT, "kotoba-whisper v2 (일본어 특화·추천)",
            "https://huggingface.co/kotoba-tech/kotoba-whisper-v2.0-ggml/resolve/main/ggml-kotoba-whisper-v2.0-q5_0.bin",
            "ggml-kotoba-whisper-v2.0-q5_0.bin", 538
        ),
        ModelDef(
            "small", ModelKind.STT, "whisper small (가볍고 빠름)",
            "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small-q5_1.bin",
            "ggml-small-q5_1.bin", 190
        ),
    )

    val MT = listOf(
        ModelDef(
            "hymt2", ModelKind.MT, "Hy-MT2 1.8B (번역 전용·추천)",
            "https://huggingface.co/tencent/Hy-MT2-1.8B-GGUF/resolve/main/Hy-MT2-1.8B-Q4_K_M.gguf",
            "Hy-MT2-1.8B-Q4_K_M.gguf", 1130
        ),
        ModelDef(
            "qwen3", ModelKind.MT, "Qwen3 1.7B (범용 LLM)",
            "https://huggingface.co/unsloth/Qwen3-1.7B-GGUF/resolve/main/Qwen3-1.7B-Q4_K_M.gguf",
            "Qwen3-1.7B-Q4_K_M.gguf", 1110
        ),
    )

    fun dir(ctx: Context): File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "models").apply { mkdirs() }
    fun file(ctx: Context, m: ModelDef) = File(dir(ctx), m.fileName)
    fun isReady(ctx: Context, m: ModelDef) = file(ctx, m).let { it.exists() && it.length() > 1_000_000 }

    fun byId(id: String?): ModelDef? = (STT + MT).firstOrNull { it.id == id }

    /**
     * 이어받기 지원 다운로드. onProgress(받은 MB, 전체 MB)
     * 완료되면 .part → 최종 파일로 이름 변경.
     */
    fun download(ctx: Context, m: ModelDef, onProgress: (Long, Long) -> Unit, cancelled: () -> Boolean) {
        val target = file(ctx, m)
        val part = File(target.path + ".part")
        var url = URL(m.url)
        var conn: HttpURLConnection
        var redirects = 0
        while (true) {
            conn = url.openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = false
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.setRequestProperty("User-Agent", "jpsub/1.0")
            if (part.exists() && part.length() > 0) conn.setRequestProperty("Range", "bytes=${part.length()}-")
            val code = conn.responseCode
            if (code in 300..399 && redirects < 10) {
                val loc = conn.getHeaderField("Location") ?: throw Exception("리다이렉트 주소 없음")
                url = URL(url, loc)
                conn.disconnect()
                redirects++
                continue
            }
            if (code == 416) { // 이미 다 받음
                conn.disconnect()
                part.renameTo(target)
                return
            }
            if (code != 200 && code != 206) throw Exception("HTTP $code")
            break
        }
        val append = conn.responseCode == 206
        val already = if (append) part.length() else 0L
        val total = already + conn.contentLengthLong.coerceAtLeast(0)
        conn.inputStream.use { input ->
            FileOutputStream(part, append).use { out ->
                val buf = ByteArray(1 shl 16)
                var done = already
                var lastReport = 0L
                while (true) {
                    if (cancelled()) throw InterruptedException("취소됨")
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (done - lastReport > 2_000_000) {
                        lastReport = done
                        onProgress(done, total)
                    }
                }
                onProgress(done, total)
            }
        }
        conn.disconnect()
        if (total > 0 && part.length() < total) throw Exception("다운로드가 끊겼어요. 다시 누르면 이어받아요.")
        if (!part.renameTo(target)) throw Exception("파일 저장 실패")
    }
}

object Prefs {
    private const val NAME = "jpsub"
    fun sp(ctx: Context) = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun sttId(ctx: Context) = sp(ctx).getString("stt", "kotoba")!!
    fun mtId(ctx: Context) = sp(ctx).getString("mt", "hymt2")!!
    fun textSize(ctx: Context) = sp(ctx).getInt("textSize", 20)
    fun showOriginal(ctx: Context) = sp(ctx).getBoolean("showOriginal", true)
    fun useContext(ctx: Context) = sp(ctx).getBoolean("useContext", true)
    fun overlayY(ctx: Context) = sp(ctx).getInt("overlayY", -1)

    fun set(ctx: Context, key: String, v: Any) {
        val e = sp(ctx).edit()
        when (v) {
            is String -> e.putString(key, v)
            is Int -> e.putInt(key, v)
            is Boolean -> e.putBoolean(key, v)
        }
        e.apply()
    }
}
