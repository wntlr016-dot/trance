package com.personal.jpsub

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale

/**
 * 진단 기록: 최근 60초 캡처 오디오(WAV)와 인식·번역 기록(TXT)을
 * '다운로드/jpsub' 폴더에 저장. 무엇이 잘못되는지(캡처/인식/번역) 확인용.
 */
class DebugSaver {
    private val ring = FloatArray(16000 * 60)
    private var total = 0L
    private val lines = Collections.synchronizedList(ArrayList<String>())
    private val t0 = System.currentTimeMillis()

    @Synchronized
    fun addAudio(samples: FloatArray) {
        for (v in samples) { ring[(total % ring.size).toInt()] = v; total++ }
    }

    fun log(msg: String) {
        val sec = (System.currentTimeMillis() - t0) / 1000f
        lines += "[%6.1f] %s".format(sec, msg)
    }

    fun save(ctx: Context): String? = runCatching {
        val stamp = SimpleDateFormat("MMdd_HHmmss", Locale.US).format(Date())
        write(ctx, "jpsub_${stamp}_log.txt", "text/plain", lines.joinToString("\n").toByteArray())
        write(ctx, "jpsub_${stamp}_audio.wav", "audio/wav", wav())
        "다운로드/jpsub 폴더"
    }.getOrNull()

    @Synchronized
    private fun wav(): ByteArray {
        val n = minOf(total, ring.size.toLong()).toInt()
        val start = total - n
        val pcm = ByteArray(n * 2)
        for (i in 0 until n) {
            val v = (ring[((start + i) % ring.size).toInt()].coerceIn(-1f, 1f) * 32767).toInt()
            pcm[2 * i] = (v and 0xff).toByte()
            pcm[2 * i + 1] = ((v shr 8) and 0xff).toByte()
        }
        val out = ByteArrayOutputStream()
        fun i32(x: Int) { out.write(x and 0xff); out.write((x shr 8) and 0xff); out.write((x shr 16) and 0xff); out.write((x shr 24) and 0xff) }
        fun i16(x: Int) { out.write(x and 0xff); out.write((x shr 8) and 0xff) }
        out.write("RIFF".toByteArray()); i32(36 + pcm.size); out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray()); i32(16); i16(1); i16(1); i32(16000); i32(32000); i16(2); i16(16)
        out.write("data".toByteArray()); i32(pcm.size); out.write(pcm)
        return out.toByteArray()
    }

    private fun write(ctx: Context, name: String, mime: String, data: ByteArray) {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/jpsub")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw Exception("저장 실패")
        ctx.contentResolver.openOutputStream(uri)!!.use { it.write(data) }
    }
}
