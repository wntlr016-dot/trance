package com.personal.jpsub

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val REQ_CAPTURE = 100
    private val REQ_PERMS = 101

    private lateinit var permText: TextView
    private lateinit var sttGroup: RadioGroup
    private lateinit var mtGroup: RadioGroup
    private lateinit var dlButton: Button
    private lateinit var dlText: TextView
    private lateinit var dlBar: ProgressBar
    private lateinit var startButton: Button

    @Volatile private var downloading = false
    @Volatile private var cancelDownload = false

    private fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(40))
        }
        setContentView(ScrollView(this).apply { addView(col) })

        col.addView(title("일본어 영상 실시간 자막", 24f))
        col.addView(note("영상 속 일본어를 듣고 한국어 자막을 플로팅 창으로 띄워요. 모든 처리는 폰 안에서 이뤄져요(무료·오프라인)."))

        // 1. 권한
        col.addView(header("1. 권한"))
        permText = note("")
        col.addView(permText)
        col.addView(button("다른 앱 위에 표시 권한 열기") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(button("오디오·알림 권한 요청") { requestRuntimePerms() })

        // 2. 모델
        col.addView(header("2. 모델"))
        col.addView(note("음성 인식 (일본어 듣기)"))
        sttGroup = radioGroup(Models.STT, Prefs.sttId(this)) { Prefs.set(this, "stt2", it) }
        col.addView(sttGroup)
        col.addView(note("번역 (일본어 → 한국어)"))
        mtGroup = radioGroup(Models.MT, Prefs.mtId(this)) { Prefs.set(this, "mt", it) }
        col.addView(mtGroup)

        dlButton = button("선택한 모델 다운로드") { onDownloadClicked() }
        col.addView(dlButton)
        dlBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000; visibility = View.GONE
        }
        col.addView(dlBar)
        dlText = note("Wi-Fi에서 받는 걸 권장해요. 중간에 끊겨도 다시 누르면 이어받아요.")
        col.addView(dlText)

        // 3. 설정
        col.addView(header("3. 자막 설정"))
        val sizeLabel = note("글자 크기: ${Prefs.textSize(this)}")
        col.addView(sizeLabel)
        col.addView(SeekBar(this).apply {
            max = 20
            progress = Prefs.textSize(this@MainActivity) - 14
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    Prefs.set(this@MainActivity, "textSize", p + 14)
                    sizeLabel.text = "글자 크기: ${p + 14}"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        col.addView(CheckBox(this).apply {
            text = "앞 대사를 참고해서 번역 (더 자연스럽지만 약간 느려짐)"
            isChecked = Prefs.useContext(this@MainActivity)
            setOnCheckedChangeListener { _, c -> Prefs.set(this@MainActivity, "useContext", c) }
        })
        col.addView(CheckBox(this).apply {
            text = "자막 창에 처리 시간 표시 (인식/번역 몇 초 걸렸는지)"
            isChecked = Prefs.showTiming(this@MainActivity)
            setOnCheckedChangeListener { _, c -> Prefs.set(this@MainActivity, "showTiming", c) }
        })
        col.addView(note("자막 창: 드래그로 이동 · 탭하면 일본어 원문 보이기/숨기기 · ✕로 종료"))

        // 4. 시작
        col.addView(header("4. 실행"))
        startButton = button("자막 시작") { onStartClicked() }.apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        }
        col.addView(startButton)
        col.addView(note("시작하면 '화면 공유/녹화' 확인창이 떠요. 소리를 가져오기 위한 절차라 화면은 저장되지 않아요. '전체 화면'을 선택하세요.\n\n넷플릭스처럼 소리 캡처를 막아 둔 앱은 자막이 안 나올 수 있어요. 유튜브·브라우저·동영상 파일은 대부분 돼요."))
    }

    override fun onResume() {
        super.onResume()
        Models.migrate(this)
        refresh()
    }

    // ───────── 상태 갱신 ─────────

    private fun refresh() {
        val overlay = Settings.canDrawOverlays(this)
        val audio = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        permText.text = "다른 앱 위에 표시: ${if (overlay) "✅" else "❌"}    오디오: ${if (audio) "✅" else "❌"}"
        updateRadioLabels(sttGroup, Models.STT)
        updateRadioLabels(mtGroup, Models.MT)
        startButton.text = if (CaptureService.running) "자막 중지" else "자막 시작"
    }

    private fun updateRadioLabels(g: RadioGroup, list: List<ModelDef>) {
        for (i in 0 until g.childCount) {
            val rb = g.getChildAt(i) as RadioButton
            val m = list[i]
            rb.text = "${m.label}\n   ${if (Models.isReady(this, m)) "✅ 받음" else "⬇ ${m.sizeMb}MB"}"
        }
    }

    // ───────── 권한 ─────────

    private fun requestRuntimePerms() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(perms.toTypedArray(), REQ_PERMS)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    // ───────── 다운로드 ─────────

    private fun onDownloadClicked() {
        if (downloading) { cancelDownload = true; return }
        val targets = listOfNotNull(Models.VAD, Models.byId(Prefs.sttId(this)), Models.byId(Prefs.mtId(this)))
            .filter { !Models.isReady(this, it) }
        if (targets.isEmpty()) { toast("선택한 모델은 이미 받았어요"); return }

        downloading = true; cancelDownload = false
        dlButton.text = "다운로드 취소"
        dlBar.visibility = View.VISIBLE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Thread {
            var err: String? = null
            for (m in targets) {
                try {
                    Models.download(this, m, { name, done, total ->
                        runOnUiThread {
                            dlText.text = "${m.label}\n$name  ${done / 1_000_000}MB / ${if (total > 0) "${total / 1_000_000}MB" else "?"}"
                            if (total > 0) dlBar.progress = (done * 1000 / total).toInt()
                        }
                    }, { cancelDownload })
                } catch (e: Throwable) {
                    err = e.message ?: e.toString()
                    break
                }
            }
            runOnUiThread {
                downloading = false
                dlButton.text = "선택한 모델 다운로드"
                dlBar.visibility = View.GONE
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                dlText.text = err?.let { "⚠ $it" } ?: "다운로드 완료!"
                refresh()
            }
        }.start()
    }

    // ───────── 시작/중지 ─────────

    private fun onStartClicked() {
        if (CaptureService.running) {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
            startButton.postDelayed({ refresh() }, 500)
            return
        }
        if (!Settings.canDrawOverlays(this)) { toast("먼저 '다른 앱 위에 표시' 권한을 켜 주세요"); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestRuntimePerms(); return
        }
        val stt = Models.byId(Prefs.sttId(this))!!
        val mt = Models.byId(Prefs.mtId(this))!!
        if (!Models.isReady(this, stt) || !Models.isReady(this, mt) || !Models.isReady(this, Models.VAD)) { toast("선택한 모델을 먼저 다운로드하세요"); return }

        val mpm = getSystemService(MediaProjectionManager::class.java)!!
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Activity result API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        if (resultCode != RESULT_OK || data == null) { toast("화면 공유를 허용해야 소리를 가져올 수 있어요"); return }
        val i = Intent(this, CaptureService::class.java)
            .putExtra(CaptureService.EXTRA_CODE, resultCode)
            .putExtra(CaptureService.EXTRA_DATA, data)
        startForegroundService(i)
        startButton.postDelayed({ refresh() }, 500)
        toast("자막 시작! 영상 앱으로 이동하세요")
        moveTaskToBack(true)
    }

    // ───────── UI 헬퍼 ─────────

    private fun title(t: String, size: Float) = TextView(this).apply {
        text = t; setTextSize(TypedValue.COMPLEX_UNIT_SP, size); setTypeface(typeface, Typeface.BOLD)
        setPadding(0, 0, 0, dp(8))
    }

    private fun header(t: String) = TextView(this).apply {
        text = t; setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f); setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(24), 0, dp(6))
    }

    private fun note(t: String) = TextView(this).apply {
        text = t; setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f); setPadding(0, dp(4), 0, dp(4))
    }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { onClick() }
    }

    private fun radioGroup(list: List<ModelDef>, selected: String, onSelect: (String) -> Unit) =
        RadioGroup(this).apply {
            list.forEachIndexed { idx, m ->
                addView(RadioButton(this@MainActivity).apply {
                    id = View.generateViewId()
                    text = m.label
                    tag = m.id
                    isChecked = m.id == selected
                    setPadding(dp(4), dp(6), 0, dp(6))
                })
            }
            setOnCheckedChangeListener { g, checkedId ->
                g.findViewById<RadioButton>(checkedId)?.tag?.let { onSelect(it as String) }
            }
        }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
