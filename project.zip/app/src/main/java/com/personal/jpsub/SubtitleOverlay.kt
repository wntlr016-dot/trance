package com.personal.jpsub

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * 다른 앱 위에 떠 있는 자막 창.
 *  - 드래그: 위치 이동 (세로 위치는 저장됨)
 *  - 한 번 탭: 일본어 원문 보이기/숨기기
 *  - 오른쪽 위 ✕: 자막 종료
 */
@SuppressLint("ClickableViewAccessibility")
class SubtitleOverlay(private val ctx: Context, private val onClose: () -> Unit) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val root = FrameLayout(ctx)
    private val jaView = TextView(ctx)
    private val koView = TextView(ctx)
    private val params: WindowManager.LayoutParams
    private var showOriginal = Prefs.showOriginal(ctx)
    private var attached = false

    init {
        val dp = { v: Float -> TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, ctx.resources.displayMetrics).toInt() }
        val size = Prefs.textSize(ctx).toFloat()

        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14f), dp(8f), dp(30f), dp(10f))
            background = GradientDrawable().apply {
                cornerRadius = dp(12f).toFloat()
                setColor(Color.argb(190, 0, 0, 0))
            }
        }
        jaView.apply {
            setTextColor(Color.rgb(190, 190, 190))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size * 0.7f)
            visibility = if (showOriginal) View.VISIBLE else View.GONE
        }
        koView.apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            setShadowLayer(4f, 0f, 1f, Color.BLACK)
            text = "자막 준비 중…"
        }
        box.addView(jaView)
        box.addView(koView)
        root.addView(box, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))

        val close = TextView(ctx).apply {
            text = "✕"
            setTextColor(Color.rgb(220, 220, 220))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setPadding(dp(8f), dp(4f), dp(8f), dp(4f))
            setOnClickListener { onClose() }
        }
        root.addView(close, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.TOP))

        val screenW = ctx.resources.displayMetrics.widthPixels
        val screenH = ctx.resources.displayMetrics.heightPixels
        params = WindowManager.LayoutParams(
            (screenW * 0.92f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (screenW * 0.04f).toInt()
            val saved = Prefs.overlayY(ctx)
            y = if (saved >= 0) saved else (screenH * 0.70f).toInt()
        }

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = params.x; startY = params.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        params.x = startX + dx.toInt()
                        params.y = (startY + dy.toInt()).coerceAtLeast(0)
                        if (attached) wm.updateViewLayout(root, params)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) Prefs.set(ctx, "overlayY", params.y)
                    else toggleOriginal()
                }
            }
            true
        }
    }

    fun show() {
        if (!attached) { wm.addView(root, params); attached = true }
    }

    fun remove() {
        if (attached) { runCatching { wm.removeView(root) }; attached = false }
    }

    fun setStatus(msg: String) {
        koView.text = msg
    }

    /** 인식된 일본어를 먼저 보여주고, 번역이 오면 교체 */
    fun showJapanese(ja: String) {
        jaView.text = ja
        if (!showOriginal) koView.text = "…"
    }

    fun showTranslation(ja: String, ko: String) {
        jaView.text = ja
        koView.text = ko.ifBlank { "(번역 실패)" }
    }

    private fun toggleOriginal() {
        showOriginal = !showOriginal
        Prefs.set(ctx, "showOriginal", showOriginal)
        jaView.visibility = if (showOriginal) View.VISIBLE else View.GONE
    }
}
