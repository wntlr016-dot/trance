package com.personal.jpsub

/** whisper.cpp 음성 인식 (libjpsub_whisper.so) */
object WhisperLib {
    init { System.loadLibrary("jpsub_whisper") }

    external fun init(modelPath: String): Long
    external fun free(ctx: Long)
    /** 16kHz mono float PCM → UTF-8 바이트 */
    external fun transcribe(ctx: Long, samples: FloatArray, lang: String, threads: Int, audioCtx: Int): ByteArray
}

/** llama.cpp 번역 LLM (libjpsub_llama.so) */
object LlamaLib {
    init { System.loadLibrary("jpsub_llama") }

    external fun init(modelPath: String, nCtx: Int, threads: Int): Long
    external fun free(handle: Long)
    /** 사용자 프롬프트(채팅 템플릿은 네이티브에서 적용) → UTF-8 바이트 */
    external fun generate(handle: Long, prompt: String, maxTokens: Int): ByteArray
}
