plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// sherpa-onnx AAR(50MB)은 GitHub 웹 업로드 한도(25MB)를 넘어서 저장소에 넣지 않고, 빌드할 때 자동으로 받음
val sherpaAar = file("libs/sherpa-onnx-1.13.8.aar")
if (!sherpaAar.exists()) {
    sherpaAar.parentFile.mkdirs()
    uri("https://github.com/k2-fsa/sherpa-onnx/releases/download/v1.13.8/sherpa-onnx-1.13.8.aar")
        .toURL().openStream().use { input -> sherpaAar.outputStream().use { input.copyTo(it) } }
}

android {
    namespace = "com.personal.jpsub"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.personal.jpsub"
        minSdk = 29
        targetSdk = 35
        versionCode = 3
        versionName = "1.2"

        ndk { abiFilters += "arm64-v8a" }
    }

    // 항상 같은 키로 서명해서, 새로 빌드한 APK를 지우지 않고 덮어 설치할 수 있게 함 (개인용)
    signingConfigs {
        create("personal") {
            storeFile = file("personal.jks")
            storePassword = "jpsub1234"
            keyAlias = "jpsub"
            keyPassword = "jpsub1234"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("personal")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core:1.13.1")
    // sherpa-onnx (ReazonSpeech 음성 인식 + Silero VAD). AAR은 위에서 자동으로 받음
    implementation(files("libs/sherpa-onnx-1.13.8.aar"))
    implementation(project(":whisper"))
    implementation(project(":llama"))
}
