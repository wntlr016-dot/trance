plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.personal.jpsub"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.personal.jpsub"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        ndk { abiFilters += "arm64-v8a" }
    }

    // 항상 같은 키로 서명해서, 새로 빌드한 APK를 지우지 않고 덮어 설치할 수 있게 함 (개인용)
    signingConfigs {
        create("personal") {
            storeFile = file("personal.jks")
            storePassword = "jpsub1234"
            keyAlias = "jpsub"
            keyPassword = "jpsub1234"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("personal")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core:1.13.1")
    implementation(project(":whisper"))
    implementation(project(":llama"))
}
